export { default } from './Paper';
export * from './Paper';
