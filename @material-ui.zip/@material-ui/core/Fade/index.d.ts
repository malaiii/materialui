export { default } from './Fade';
export * from './Fade';
